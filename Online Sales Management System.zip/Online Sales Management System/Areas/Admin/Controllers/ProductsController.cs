using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnlineSalesManagementSystem.Data;
using OnlineSalesManagementSystem.Domain.Entities;
using OnlineSalesManagementSystem.Services.Security;
using System.IO;

namespace OnlineSalesManagementSystem.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize(Policy = PermissionConstants.PolicyPrefix + PermissionConstants.Modules.Products + "." + PermissionConstants.Actions.Show)]
public class ProductsController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly IWebHostEnvironment _env;

    public ProductsController(ApplicationDbContext db, IWebHostEnvironment env)
    {
        _db = db;
        _env = env;
    }

    [HttpGet]
    public async Task<IActionResult> Index(string? q, int page = 1, int pageSize = 10)
    {
        if (page <= 0) page = 1;
        if (pageSize <= 0) pageSize = 10;
        if (pageSize > 100) pageSize = 100;

        var query = _db.Products
            .AsNoTracking()
            .Include(p => p.Category)
            .Include(p => p.Unit)
            .Where(p => p.IsActive)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(q))
        {
            q = q.Trim();
            query = query.Where(p => p.SKU.Contains(q) || p.Name.Contains(q));
        }

        var total = await query.CountAsync();

        var items = await query
            .OrderByDescending(p => p.IsTrending)
            .ThenBy(p => p.Name)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();

        ViewBag.Query = q;
        ViewBag.Page = page;
        ViewBag.PageSize = pageSize;
        ViewBag.Total = total;

        return View(items);
    }

    // ====== DETAILS: thông tin sản phẩm + lịch sử hóa đơn có sản phẩm này ======
    [HttpGet]
    public async Task<IActionResult> Details(int id)
    {
        var product = await _db.Products
            .AsNoTracking()
            .Include(p => p.Category)
            .Include(p => p.Unit)
            .FirstOrDefaultAsync(p => p.Id == id);

        if (product == null) return NotFound();

        var orders = await _db.Invoices
            .AsNoTracking()
            .Include(i => i.Customer)
            .Include(i => i.Items)
            .Where(i => i.Items.Any(it => it.ProductId == id))
            .OrderByDescending(i => i.InvoiceDate)
            .Select(i => new ProductOrderRow
            {
                InvoiceId = i.Id,
                InvoiceNo = i.InvoiceNo,
                CustomerId = i.CustomerId,
                CustomerName = i.Customer != null ? i.Customer.Name : "Khách lẻ",
                InvoiceDate = i.InvoiceDate,
                Qty = i.Items.Where(it => it.ProductId == id).Sum(it => it.Quantity),
                UnitPrice = i.Items.Where(it => it.ProductId == id).Select(it => it.UnitPrice).FirstOrDefault(),
                LineTotal = i.Items.Where(it => it.ProductId == id).Sum(it => it.LineTotal),
                Status = i.Status
            })
            .ToListAsync();

        var vm = new ProductDetailsVm
        {
            Product = product,
            Orders = orders,
            TotalSoldQty = orders.Sum(x => x.Qty),
            TotalRevenue = orders.Sum(x => x.LineTotal)
        };

        return View(vm);
    }

    // ========= CREATE =========
    [Authorize(Policy = PermissionConstants.PolicyPrefix + PermissionConstants.Modules.Products + "." + PermissionConstants.Actions.Create)]
    [HttpGet]
    public async Task<IActionResult> Create()
    {
        await LoadLookupsAsync();
        // Default values
        return View(new Product
        {
            IsActive = true,
            IsTrending = false,
            StockOnHand = 0,
            ReorderLevel = 0,
            CostPrice = 0m,
            SalePrice = 0m
        });
    }

    [Authorize(Policy = PermissionConstants.PolicyPrefix + PermissionConstants.Modules.Products + "." + PermissionConstants.Actions.Create)]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Product model, IFormFile? imageFile)
    {
        Normalize(model);

        // Validate dropdowns: treat 0 as null
        if (model.CategoryId.HasValue && model.CategoryId.Value <= 0) model.CategoryId = null;
        if (model.UnitId.HasValue && model.UnitId.Value <= 0) model.UnitId = null;
        if (model.BrandId.HasValue && model.BrandId.Value <= 0) model.BrandId = null;

        if (string.IsNullOrWhiteSpace(model.SKU))
            ModelState.AddModelError(nameof(model.SKU), "SKU is required.");

        if (string.IsNullOrWhiteSpace(model.Name))
            ModelState.AddModelError(nameof(model.Name), "Product name is required.");

        if (model.CategoryId == null)
            ModelState.AddModelError(nameof(model.CategoryId), "Please select a category.");

        if (model.UnitId == null)
            ModelState.AddModelError(nameof(model.UnitId), "Please select a unit.");

        if (model.CostPrice < 0) ModelState.AddModelError(nameof(model.CostPrice), "Cost price must be >= 0.");
        if (model.SalePrice < 0) ModelState.AddModelError(nameof(model.SalePrice), "Sale price must be >= 0.");
        if (model.StockOnHand < 0) ModelState.AddModelError(nameof(model.StockOnHand), "Stock must be >= 0.");
        if (model.ReorderLevel < 0) ModelState.AddModelError(nameof(model.ReorderLevel), "Reorder level must be >= 0.");

        // Image: only one source allowed (file or URL) to avoid confusion
        if (imageFile != null && imageFile.Length > 0 && !string.IsNullOrWhiteSpace(model.ImagePath))
        {
            ModelState.AddModelError(nameof(model.ImagePath), "Please choose either an upload image OR an image URL, not both.");
        }

        if (!ModelState.IsValid)
        {
            await LoadLookupsAsync();
            return View(model);
        }

        try
        {
            // Ensure category/unit/brand exist and active (business safety)
            var catOk = await _db.Categories.AsNoTracking().AnyAsync(c => c.Id == model.CategoryId && c.IsActive);
            if (!catOk)
            {
                ModelState.AddModelError(nameof(model.CategoryId), "Selected category is not valid.");
                await LoadLookupsAsync();
                return View(model);
            }

            var unitOk = await _db.Units.AsNoTracking().AnyAsync(u => u.Id == model.UnitId && u.IsActive);
            if (!unitOk)
            {
                ModelState.AddModelError(nameof(model.UnitId), "Selected unit is not valid.");
                await LoadLookupsAsync();
                return View(model);
            }

            if (model.BrandId.HasValue)
            {
                var brandOk = await _db.Brands.AsNoTracking().AnyAsync(b => b.Id == model.BrandId && b.IsActive);
                if (!brandOk)
                {
                    ModelState.AddModelError(nameof(model.BrandId), "Selected brand is not valid.");
                    await LoadLookupsAsync();
                    return View(model);
                }
            }

            // Check SKU uniqueness (case-insensitive)
            var existing = await _db.Products.FirstOrDefaultAsync(p => p.SKU.ToLower() == model.SKU.ToLower());
            if (existing != null)
            {
                if (existing.IsActive)
                {
                    ModelState.AddModelError(nameof(model.SKU), "SKU already exists.");
                    await LoadLookupsAsync();
                    return View(model);
                }

                // Restore soft-deleted product
                existing.IsActive = true;
                existing.Name = model.Name;
                existing.CategoryId = model.CategoryId;
                existing.UnitId = model.UnitId;
                existing.BrandId = model.BrandId;
                existing.Description = model.Description;
                existing.Content = model.Content;
                existing.CostPrice = model.CostPrice;
                existing.SalePrice = model.SalePrice;
                existing.ReorderLevel = model.ReorderLevel;
                existing.StockOnHand = model.StockOnHand;
                existing.IsTrending = model.IsTrending;

                // Image handling
                existing.ImagePath = await SaveProductImageAsync(imageFile, model.ImagePath);

                await _db.SaveChangesAsync();
                TempData["ToastSuccess"] = "Product restored.";
                return RedirectToAction(nameof(Index));
            }

            model.IsActive = true;
            model.ImagePath = await SaveProductImageAsync(imageFile, model.ImagePath);

            _db.Products.Add(model);
            await _db.SaveChangesAsync();

            TempData["ToastSuccess"] = "Product created.";
            return RedirectToAction(nameof(Index));
        }
        catch (Exception ex)
        {
            // If upload succeeded but DB failed, we don't delete file automatically (avoid deleting used file).
            TempData["ToastError"] = "Failed to create product. " + ex.Message;
            await LoadLookupsAsync();
            return View(model);
        }
    }

    // ==========================================================
    // CÁC HÀM EDIT ĐÃ ĐƯỢC BỔ SUNG ĐỂ SỬA LỖI 404
    // ==========================================================

    // 1. GET: Hiển thị form chỉnh sửa
    [HttpGet]
    [Authorize(Policy = PermissionConstants.PolicyPrefix + PermissionConstants.Modules.Products + "." + PermissionConstants.Actions.Edit)]
    public async Task<IActionResult> Edit(int id)
    {
        var product = await _db.Products.FindAsync(id);
        if (product == null) return NotFound();

        // Lấy danh sách danh mục & đơn vị tính để hiển thị dropdown
        ViewBag.Categories = await _db.Categories.ToListAsync();
        ViewBag.Units = await _db.Units.ToListAsync();

        return View(product);
    }

    // 2. POST: Xử lý lưu thay đổi
    // Lưu ý: Route("Edit/{id?}") giúp chấp nhận cả URL có ID (Edit/10) và không ID (Edit)
    [HttpPost("Edit/{id?}")]
    [Authorize(Policy = PermissionConstants.PolicyPrefix + PermissionConstants.Modules.Products + "." + PermissionConstants.Actions.Edit)]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(Product model)
    {
        // Tìm sản phẩm cũ trong database
        var existing = await _db.Products.FindAsync(model.Id);
        if (existing == null) return NotFound();

        // Cập nhật thông tin mới
        existing.SKU = model.SKU;
        existing.Name = model.Name;
        existing.CategoryId = model.CategoryId;
        existing.UnitId = model.UnitId;
        existing.Description = model.Description;
        existing.SalePrice = model.SalePrice;
        existing.CostPrice = model.CostPrice;
        existing.ReorderLevel = model.ReorderLevel;
        existing.ImagePath = model.ImagePath;
        existing.IsTrending = model.IsTrending;
        existing.IsActive = model.IsActive;

        // Lưu xuống database
        _db.Products.Update(existing);
        await _db.SaveChangesAsync();

        // Quay về trang danh sách
        return RedirectToAction(nameof(Index));
    }

    // ========= HELPERS =========
    private async Task LoadLookupsAsync()
    {
        ViewBag.Categories = await _db.Categories.AsNoTracking()
            .Where(c => c.IsActive)
            .OrderBy(c => c.Name)
            .ToListAsync();

        ViewBag.Units = await _db.Units.AsNoTracking()
            .Where(u => u.IsActive)
            .OrderBy(u => u.Name)
            .ToListAsync();

        ViewBag.Brands = await _db.Brands.AsNoTracking()
            .Where(b => b.IsActive)
            .OrderBy(b => b.Name)
            .ToListAsync();
    }

    private static void Normalize(Product model)
    {
        model.SKU = (model.SKU ?? string.Empty).Trim();
        model.Name = (model.Name ?? string.Empty).Trim();
        model.ImagePath = string.IsNullOrWhiteSpace(model.ImagePath) ? null : model.ImagePath.Trim();
        model.Description = string.IsNullOrWhiteSpace(model.Description) ? null : model.Description.Trim();
        model.Content = string.IsNullOrWhiteSpace(model.Content) ? null : model.Content.Trim();

        // Hard safety for money values
        model.CostPrice = Math.Max(0m, model.CostPrice);
        model.SalePrice = Math.Max(0m, model.SalePrice);
        model.StockOnHand = Math.Max(0, model.StockOnHand);
        model.ReorderLevel = Math.Max(0, model.ReorderLevel);
    }

    private async Task<string?> SaveProductImageAsync(IFormFile? imageFile, string? imageUrl)
    {
        // If user provided URL only
        if ((imageFile == null || imageFile.Length == 0) && !string.IsNullOrWhiteSpace(imageUrl))
            return imageUrl.Trim();

        if (imageFile == null || imageFile.Length == 0)
            return null;

        // Validate extension
        var ext = Path.GetExtension(imageFile.FileName).ToLowerInvariant();
        var allowed = new[] { ".png", ".jpg", ".jpeg", ".webp" };
        if (!allowed.Contains(ext))
            throw new InvalidOperationException("Invalid image type. Allowed: png/jpg/jpeg/webp.");

        // Validate size (5 MB)
        const long maxBytes = 5 * 1024 * 1024;
        if (imageFile.Length > maxBytes)
            throw new InvalidOperationException("Image too large. Max 5MB.");

        var uploadsRoot = Path.Combine(_env.WebRootPath, "uploads", "products");
        Directory.CreateDirectory(uploadsRoot);

        var safeSku = string.IsNullOrWhiteSpace(imageUrl)
            ? Guid.NewGuid().ToString("N")
            : Guid.NewGuid().ToString("N");
        var fileName = $"{safeSku}{ext}";
        var fullPath = Path.Combine(uploadsRoot, fileName);

        await using var stream = new FileStream(fullPath, FileMode.Create);
        await imageFile.CopyToAsync(stream);

        return $"/uploads/products/{fileName}";
    }

    // ==========================================================

    // ====== TOGGLE TRENDING ======
    [Authorize(Policy = PermissionConstants.PolicyPrefix + PermissionConstants.Modules.Products + "." + PermissionConstants.Actions.Edit)]
    [HttpPost]
    public async Task<IActionResult> ToggleTrending(int id)
    {
        var entity = await _db.Products.FirstOrDefaultAsync(p => p.Id == id);
        if (entity == null) return Json(new { success = false, message = "Not found" });

        entity.IsTrending = !entity.IsTrending;
        await _db.SaveChangesAsync();

        return Json(new { success = true, isTrending = entity.IsTrending });
    }

    // ====== VIEWMODELS ======
    public sealed class ProductDetailsVm
    {
        public Product Product { get; set; } = default!;
        public List<ProductOrderRow> Orders { get; set; } = new();
        public int TotalSoldQty { get; set; }
        public decimal TotalRevenue { get; set; }
    }

    public sealed class ProductOrderRow
    {
        public int InvoiceId { get; set; }
        public string InvoiceNo { get; set; } = "";
        public int? CustomerId { get; set; }
        public string CustomerName { get; set; } = "";
        public DateTime InvoiceDate { get; set; }
        public int Qty { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal LineTotal { get; set; }
        public InvoiceStatus Status { get; set; }
    }
}